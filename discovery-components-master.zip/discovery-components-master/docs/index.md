---
layout: default
title: Home
nav_order: 0
---

# Discovery Components

Documentation for a collection of React components used to interact with the IBM Watson Discovery service on CloudPakForData.
