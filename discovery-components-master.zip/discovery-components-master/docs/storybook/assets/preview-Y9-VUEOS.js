import{_ as e}from"./iframe-cza3Lajs.js";import"../sb-preview/runtime.js";var a={docs:{renderer:async()=>{let{DocsRenderer:r}=await e(()=>import("./DocsRenderer-NNNQARDV-vA64YkMu.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19]),import.meta.url);return new r}}};export{a as parameters};
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = ["./DocsRenderer-NNNQARDV-vA64YkMu.js","./iframe-cza3Lajs.js","./index-RfLt4OUa.js","./react-16-hgR7FrAp.js","./index-miLrID2P.js","./index-Uw8Rwrt7.js","./pickBy-ZgIsky0p.js","./callBound-Uz6qjr9w.js","./extends-z9a7DBh-.js","./setPrototypeOf-08Rm0-g8.js","./inheritsLoose-uwS37NTe.js","./_baseUniq-tk6_MLAQ.js","./pickBy-zEDcIzXe.js","./uniq-TDmnBOQ0.js","./cloneDeep-BBxW03fY.js","./_baseClone-YJfCp7aQ.js","./index-xck8ovCi.js","./index-U0jbV_xt.js","./assert-Q0sut4U-.js","./util-6S_QBGOh.js"]
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
