import{g as o}from"./index-RfLt4OUa.js";import{_ as r}from"./_baseClone-YJfCp7aQ.js";var a=r,n=1,t=4;function p(e){return a(e,n|t)}var s=p;const l=o(s);export{l as c};
