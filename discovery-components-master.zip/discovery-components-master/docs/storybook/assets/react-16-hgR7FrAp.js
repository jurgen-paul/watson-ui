import{R as n}from"./index-miLrID2P.js";var m=async(e,r)=>new Promise(t=>{n.render(e,r,()=>t(null))}),a=e=>{n.unmountComponentAtNode(e)};export{m as r,a as u};
