import{_ as e}from"./setPrototypeOf-08Rm0-g8.js";function p(o,t){o.prototype=Object.create(t.prototype),o.prototype.constructor=o,e(o,t)}export{p as _};
