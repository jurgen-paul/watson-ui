function t(n){var l=n==null?0:n.length;return l?n[l-1]:void 0}var e=t;export{e as l};
