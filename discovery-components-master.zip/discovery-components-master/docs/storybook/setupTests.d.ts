/**
 * Set up `jest` when run from `react-scripts`
 */
