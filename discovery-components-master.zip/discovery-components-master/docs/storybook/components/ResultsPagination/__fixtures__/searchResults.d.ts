declare const data: {
    matching_results: number;
    retrieval_details: {};
    results: never[];
};
export default data;
