export declare const structuredQueryClass: string;
export declare const structuredQueryRuleGroupClass: string;
export declare const structuredQueryNestedRuleGroupClass: string;
export declare const structuredQueryRuleGroupDropdownClass: string;
export declare const structuredQueryRulesClass: string;
export declare const structuredQueryRulesButtonsClass: string;
export declare const structuredQueryCopyableQueryClass: string;
