import DiscoveryV2 from 'ibm-watson/discovery/v2';
export declare const getFieldNames: (response: DiscoveryV2.ListFieldsResponse | null) => string[];
