import { StructuredQuerySelection } from './structuredQueryInterfaces';
export declare const getNewId: (currentGroupsOrRows: StructuredQuerySelection['rows'] | StructuredQuerySelection['groups']) => number;
