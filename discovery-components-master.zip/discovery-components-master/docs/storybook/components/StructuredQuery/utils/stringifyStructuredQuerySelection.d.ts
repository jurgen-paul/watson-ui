import { StructuredQuerySelection } from './structuredQueryInterfaces';
export declare const stringifyStructuredQuerySelection: (structuredQuerySelection: StructuredQuerySelection) => string;
