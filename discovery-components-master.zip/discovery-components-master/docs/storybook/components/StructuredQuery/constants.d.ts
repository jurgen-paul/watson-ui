export declare const MAX_NUM_SIBLING_RULE_ROWS = 3;
export declare const MAX_NUM_NESTED_RULE_GROUPS = 5;
