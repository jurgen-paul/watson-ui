import DiscoveryV2 from 'ibm-watson/discovery/v2';
export declare const findTablesWithoutResults: (tableResults: DiscoveryV2.QueryTableResult[], results: DiscoveryV2.QueryResult[]) => DiscoveryV2.QueryTableResult[] | null;
