import DiscoveryV2 from 'ibm-watson/discovery/v2';
export declare const COLLECTION_ID_1 = "8713a92b-28aa-b291-0000-016ddc68aa2a";
declare const collectionsResponse: DiscoveryV2.ListCollectionsResponse;
export default collectionsResponse;
