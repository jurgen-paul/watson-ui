import DiscoveryV2 from 'ibm-watson/discovery/v2';
declare const searchResults: DiscoveryV2.QueryResponse;
export default searchResults;
