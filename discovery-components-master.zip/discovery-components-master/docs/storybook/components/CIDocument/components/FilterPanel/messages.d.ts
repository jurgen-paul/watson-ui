export interface Messages {
    filterTitle?: string;
    resetFilterLabel?: string;
}
export declare const defaultMessages: Messages;
