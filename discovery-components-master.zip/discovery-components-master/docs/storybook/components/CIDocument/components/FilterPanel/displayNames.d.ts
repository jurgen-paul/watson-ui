export declare const displayNames: Record<string, string>;
