export interface Messages {
    previousLabel?: string;
    nextLabel?: string;
    counterPattern?: string;
    navigation?: string;
}
export declare const defaultMessages: Messages;
