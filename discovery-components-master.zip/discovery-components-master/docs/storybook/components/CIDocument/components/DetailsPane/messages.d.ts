export interface Messages {
    detailsTitle?: string;
    noneSelectedMessage?: string;
    noneLabel?: string;
}
export declare const defaultMessages: Messages;
