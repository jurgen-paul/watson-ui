import { Party } from '../types';
export declare const mockParties: Party[];
