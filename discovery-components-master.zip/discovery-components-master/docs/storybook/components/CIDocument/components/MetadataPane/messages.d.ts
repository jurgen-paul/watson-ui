export interface Messages {
    partiesHeading?: string;
}
export declare const defaultMessages: Messages;
