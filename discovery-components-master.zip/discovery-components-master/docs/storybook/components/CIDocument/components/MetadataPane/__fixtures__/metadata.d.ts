import { Metadata } from 'components/CIDocument/types';
export declare const mockMetadata: Metadata[];
