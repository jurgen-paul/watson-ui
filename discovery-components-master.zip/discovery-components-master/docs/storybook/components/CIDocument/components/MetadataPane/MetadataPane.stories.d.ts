declare const _default: {
    title: string;
};
export default _default;
export declare const Default: {
    render: () => JSX.Element;
    name: string;
};
