declare const _default: {
    title: string;
};
export default _default;
export declare const Simple: {
    render: () => JSX.Element;
    name: string;
};
export declare const Complex: {
    render: () => JSX.Element;
    name: string;
};
