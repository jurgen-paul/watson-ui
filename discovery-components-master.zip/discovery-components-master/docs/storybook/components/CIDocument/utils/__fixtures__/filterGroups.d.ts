import { FilterGroupWithFns } from '../filterGroups';
declare const filterGroups: FilterGroupWithFns[];
export default filterGroups;
