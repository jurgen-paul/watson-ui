export declare const documentDisplayNames: Record<string, string>;
