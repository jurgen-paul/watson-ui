declare const ErrorBoundDocumentPreview: any;
export default ErrorBoundDocumentPreview;
export { ErrorBoundDocumentPreview as DocumentPreview };
