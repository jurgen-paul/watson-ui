declare const data: {
    single: {
        passage_text: string;
        start_offset: number;
        end_offset: number;
        field: string;
    };
};
export default data;
