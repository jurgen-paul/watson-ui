export declare const document = "This is an invalid PDF document. It will not render.";
