declare const _default: {
    title: string;
    decorators: any[];
};
export default _default;
export declare const Default: {
    render: () => JSX.Element;
    name: string;
};
export declare const ParentWrapped: {
    render: () => JSX.Element;
    name: string;
};
