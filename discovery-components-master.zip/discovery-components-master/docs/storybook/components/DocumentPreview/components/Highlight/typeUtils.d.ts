import { QueryResultPassage, QueryTableResult } from 'ibm-watson/discovery/v2';
export declare function isPassage(obj: any): obj is QueryResultPassage;
export declare function isTable(highlight: any): highlight is QueryTableResult;
