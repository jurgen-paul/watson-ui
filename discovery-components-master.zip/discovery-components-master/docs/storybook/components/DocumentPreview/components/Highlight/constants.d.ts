export declare const DEFAULT_WIDTH = 612;
export declare const DEFAULT_HEIGHT = 792;
export declare const DEFAULT_ORIGIN = "BottomLeft";
export declare const PADDING = 5;
