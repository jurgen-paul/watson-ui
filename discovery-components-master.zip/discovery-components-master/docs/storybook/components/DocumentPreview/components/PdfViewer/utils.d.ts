import { DocumentInitParameters } from 'pdfjs-dist/types/src/display/api';
export declare function toPDFSource(data: NonNullable<DocumentInitParameters['data']> | DocumentInitParameters): DocumentInitParameters;
