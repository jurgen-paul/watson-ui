export { getTextBoxMappings } from './getTextBoxMapping';
