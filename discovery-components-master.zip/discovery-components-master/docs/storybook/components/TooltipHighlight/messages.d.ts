export interface Messages {
    enrichmentsHeaderLabel: string;
}
export declare const defaultMessages: Messages;
