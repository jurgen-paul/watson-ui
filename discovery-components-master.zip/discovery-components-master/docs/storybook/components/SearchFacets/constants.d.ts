export declare const MAX_FACETS_UNTIL_MODAL = 10;
export declare const MAX_FACETS_UNTIL_SEARCHBAR = 15;
