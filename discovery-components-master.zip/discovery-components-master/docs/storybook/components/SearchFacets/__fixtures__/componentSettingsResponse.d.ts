import { Response, ComponentSettingsResponse } from 'ibm-watson/discovery/v2';
declare const aggregationComponentSettingsResponse: Response<ComponentSettingsResponse>;
export default aggregationComponentSettingsResponse;
