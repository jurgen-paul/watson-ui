import { Response, ListCollectionsResponse } from 'ibm-watson/discovery/v2';
declare const collectionsResponse: Response<ListCollectionsResponse>;
export default collectionsResponse;
