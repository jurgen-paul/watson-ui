import DiscoveryV2 from 'ibm-watson/discovery/v2';
export declare const facetsQueryResponse: DiscoveryV2.Response<DiscoveryV2.QueryResponse>;
export declare const weirdFacetsQueryResponse: DiscoveryV2.Response<DiscoveryV2.QueryResponse>;
export declare const nestedFacetQueryResponse: DiscoveryV2.Response<DiscoveryV2.QueryResponse>;
export default facetsQueryResponse;
