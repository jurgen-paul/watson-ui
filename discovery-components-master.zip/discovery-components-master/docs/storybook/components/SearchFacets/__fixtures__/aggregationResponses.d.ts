import DiscoveryV2 from 'ibm-watson/discovery/v2';
export declare const twoTermAggs: DiscoveryV2.QueryResponse;
export declare const nestedTermAgg: DiscoveryV2.QueryResponse;
export declare const nestedFilterTermAgg: DiscoveryV2.QueryResponse;
export declare const twoNestedFilterTermAgg: DiscoveryV2.QueryResponse;
