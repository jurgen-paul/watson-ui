import { QueryAggregation, QueryAggregationQueryTermAggregation } from 'ibm-watson/discovery/v2';
export declare function findTermAggregations(inputAggregations?: QueryAggregation[], outputAggregations?: QueryAggregationQueryTermAggregation[]): QueryAggregationQueryTermAggregation[];
