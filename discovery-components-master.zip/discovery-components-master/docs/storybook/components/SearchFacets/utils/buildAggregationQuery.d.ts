import { QueryAggregationWithName } from './searchFacetInterfaces';
export declare const buildAggregationQuery: (configuration: QueryAggregationWithName[]) => string;
