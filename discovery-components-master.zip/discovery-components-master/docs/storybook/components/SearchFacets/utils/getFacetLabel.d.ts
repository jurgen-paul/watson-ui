/// <reference types="react" />
import { Messages } from 'components/SearchFacets/messages';
export declare const getFacetLabel: (facetText: string, count: number | undefined, messages: Messages, showMatchingResults: boolean) => import("react").ReactNode[];
