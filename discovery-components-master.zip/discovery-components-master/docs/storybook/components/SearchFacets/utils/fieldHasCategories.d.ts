import { InternalQueryTermAggregation } from './searchFacetInterfaces';
export declare function fieldHasCategories(aggregation: Pick<InternalQueryTermAggregation, 'results' | 'field'>): boolean;
