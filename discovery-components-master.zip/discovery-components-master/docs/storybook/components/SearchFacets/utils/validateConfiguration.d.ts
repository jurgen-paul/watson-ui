import { QueryAggregationQueryTermAggregation } from 'ibm-watson/discovery/v2';
export declare const validateConfiguration: (configuration: QueryAggregationQueryTermAggregation[]) => boolean;
