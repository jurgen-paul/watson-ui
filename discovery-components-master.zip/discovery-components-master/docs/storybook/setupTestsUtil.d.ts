export declare function defineDOMRect(): void;
export declare function removeDOMRect(): void;
