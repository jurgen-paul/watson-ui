export declare const FallbackComponent: (componentName: string) => () => JSX.Element;
