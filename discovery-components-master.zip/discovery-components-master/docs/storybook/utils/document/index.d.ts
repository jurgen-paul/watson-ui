export { processDoc } from 'utils/document/processDoc';
export type { ProcessedDoc, ProcessedBbox, Table } from 'utils/document/processDoc';
