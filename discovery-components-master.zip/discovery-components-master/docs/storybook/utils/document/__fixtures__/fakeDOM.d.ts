/// <reference types="react" />
export declare const nodes: JSX.Element;
