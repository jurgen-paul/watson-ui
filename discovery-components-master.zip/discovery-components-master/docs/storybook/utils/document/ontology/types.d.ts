export interface Ontology {
    enrichment: string;
    attributes: string[];
    relations: string[];
}
