declare const purchaseOrderOntology: {
    enrichment: string;
    attributes: string[];
    relations: string[];
};
export default purchaseOrderOntology;
