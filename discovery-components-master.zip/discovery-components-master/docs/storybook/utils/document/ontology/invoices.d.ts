declare const invoiceOntology: {
    enrichment: string;
    attributes: string[];
    relations: string[];
};
export default invoiceOntology;
