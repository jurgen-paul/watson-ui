import { EnrichedHtml } from 'components/CIDocument/types';
export default function transformEnrichment(enrichedHtml?: EnrichedHtml[]): EnrichedHtml[] | undefined;
