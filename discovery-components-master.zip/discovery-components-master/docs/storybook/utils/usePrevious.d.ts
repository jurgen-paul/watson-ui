export declare const usePrevious: (value: any) => undefined;
export default usePrevious;
