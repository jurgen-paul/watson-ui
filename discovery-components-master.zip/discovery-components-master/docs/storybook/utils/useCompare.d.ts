export declare const useCompare: (val: any) => boolean;
export default useCompare;
