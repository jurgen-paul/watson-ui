declare const useDebounce: (value: string, delay: number) => string;
export default useDebounce;
