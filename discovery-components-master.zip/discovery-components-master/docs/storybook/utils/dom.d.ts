export declare function clearNodeChildren(node: Node): void;
