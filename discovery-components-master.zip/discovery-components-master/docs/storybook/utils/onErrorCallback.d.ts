declare const onErrorCallback: (error: Error, componentStack: string) => void;
export default onErrorCallback;
