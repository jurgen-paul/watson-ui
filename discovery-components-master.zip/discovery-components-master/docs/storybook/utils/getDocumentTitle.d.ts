import { QueryResultWithOptionalMetadata } from 'components/DocumentPreview/types';
export declare const getDocumentTitle: (document: QueryResultWithOptionalMetadata | undefined, titleField: string) => string;
