declare function shortid(): string;
export default shortid;
