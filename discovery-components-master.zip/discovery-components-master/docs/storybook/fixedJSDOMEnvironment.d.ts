export default class FixedJSDOMEnvironment extends JSDOMEnvironment {
    constructor(...args: any[]);
}
import JSDOMEnvironment from 'jest-environment-jsdom';
