import App from '../App';

describe('App', () => {
  it('is truthy', () => {
    expect(App).toBeTruthy();
  });
});
