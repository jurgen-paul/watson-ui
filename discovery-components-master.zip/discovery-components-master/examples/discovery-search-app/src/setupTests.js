/**
 * Set up `jest` when run from `react-scripts`
 */

// polyfill for `Promise.withResolvers()`
import 'core-js/proposals/promise-with-resolvers';
