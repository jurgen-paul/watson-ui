export interface Messages {
  partiesHeading?: string;
}

export const defaultMessages: Messages = {
  partiesHeading: 'Parties'
};
