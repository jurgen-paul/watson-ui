#### Overview

The `CIDocument` component provides the user with a document enriched by one of the content intelligence enrichments. It displays a document with features a customer might deem important (such as Obligation, Deliverables, Assignments, etc...). This would help customers get a better understanding of their document, or help them find what they need in a large document in a more efficient way.
